# Ase Herbs — Stripe full-cart checkout setup

This version adds a real Stripe checkout. Your "Proceed to checkout" button now
bundles the whole cart and sends the customer to Stripe's secure payment page.

Files:
- `index.html` — the site (checkout wired to the function)
- `images/` — organ illustrations
- `api/create-checkout-session.js` — the secure serverless function

> Easiest on a laptop/desktop. The secret key needs a Git-connected Vercel
> project, which is awkward to set up from a phone.

## 1. Get your Stripe secret key
1. Create/log in at stripe.com.
2. Start in **Test mode** (toggle, top right) so you can test without real charges.
3. Developers → API keys → copy the **Secret key** (starts with `sk_test_...`).
   You'll swap in the live key (`sk_live_...`) once you've activated the account.

## 2. Put the project in GitHub
1. Create a new GitHub repo (e.g. `aseherbs`).
2. Upload `index.html`, the `images/` folder, and the `api/` folder — keeping
   `api/create-checkout-session.js` inside an `api` folder at the top level.

## 3. Import to Vercel
1. Vercel → **Add New → Project → Import** your GitHub repo.
2. Framework preset: **Other**. Leave build settings empty. Deploy.

## 4. Add the secret key (this is what makes checkout work)
1. In the project → **Settings → Environment Variables**.
2. Add: **Name** `STRIPE_SECRET_KEY`  **Value** your `sk_test_...` key.
   Apply to Production (and Preview). Mark it **Sensitive**.
3. **Redeploy** (Deployments → latest → Redeploy) so the key takes effect —
   env vars added after a build don't apply until a rebuild.

## 5. Test
1. Open your site → add items → **Proceed to checkout** → you should land on
   Stripe's page.
2. Use Stripe's test card `4242 4242 4242 4242`, any future date, any CVC/ZIP.
3. After paying you return to the site with a "Thank you" message.

## 6. Go live
1. Activate your Stripe account (business details + bank account).
2. Switch Stripe to **Live mode**, copy the `sk_live_...` key.
3. In Vercel, update `STRIPE_SECRET_KEY` to the live key → Redeploy.

## Notes
- The secret key lives only in Vercel's environment — never in the code or the
  browser. Keep it that way.
- Supplements are a scrutinized category. Keep the compliant "supports…"
  wording and the FDA disclaimer; avoid disease/ED claims so Stripe doesn't
  flag the account.
- To edit later, just push to GitHub — Vercel redeploys automatically.
