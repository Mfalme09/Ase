// Vercel serverless function: creates a Stripe Checkout Session from the cart.
// No npm dependencies — it calls the Stripe REST API directly.
// The secret key is read from the STRIPE_SECRET_KEY environment variable
// (set it in Vercel → Settings → Environment Variables — never in the code).

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) {
    res.status(500).json({ error: 'Server missing STRIPE_SECRET_KEY.' });
    return;
  }

  try {
    let body = req.body;
    if (typeof body === 'string') { try { body = JSON.parse(body); } catch (e) { body = {}; } }
    const items = body && Array.isArray(body.items) ? body.items : [];
    if (items.length === 0) {
      res.status(400).json({ error: 'Your cart is empty.' });
      return;
    }

    const origin = req.headers.origin || ('https://' + req.headers.host);

    const params = new URLSearchParams();
    params.append('mode', 'payment');
    params.append('success_url', origin + '/?success=1');
    params.append('cancel_url', origin + '/?canceled=1');
    // Collect a shipping address at checkout (US only — edit as needed).
    params.append('shipping_address_collection[allowed_countries][0]', 'US');

    items.forEach((it, i) => {
      const qty = Math.max(1, parseInt(it.qty, 10) || 1);
      const cents = Math.round(Number(it.price) * 100);
      if (!it.name || !(cents > 0)) return;
      params.append('line_items[' + i + '][quantity]', String(qty));
      params.append('line_items[' + i + '][price_data][currency]', 'usd');
      params.append('line_items[' + i + '][price_data][unit_amount]', String(cents));
      params.append('line_items[' + i + '][price_data][product_data][name]', String(it.name).slice(0, 250));
    });

    const stripeRes = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + key,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: params.toString()
    });

    const data = await stripeRes.json();
    if (!stripeRes.ok) {
      res.status(400).json({ error: (data && data.error && data.error.message) || 'Stripe error.' });
      return;
    }

    res.status(200).json({ url: data.url });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Unexpected error.' });
  }
};
